#include <stdio.h>

int main()
{
    int A, B, troca;
    printf("Digite o valor A: ");
    scanf("%d", &A);
    
    printf("Digite o valor B: ");
    scanf("%d", &B);

    troca = A;
    A = B;
    B = troca;
    
    printf("A = %d, B= %d", A, B);
}