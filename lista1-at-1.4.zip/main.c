/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main()
{
    float raio, area, x;
    printf("Digite o ráio do círculo: ");
    scanf("%f", &raio);
    
    x = pow(raio, 2);
    area = M_PI * x;
    
    printf("A área do círculo é: %f", area);
}

