/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float a, b, c, media;
    printf("Digite a Primeira nota: ");
    scanf("%f", &a);

    printf("Digite a Segunda nota: ");
    scanf("%f", &b);

    printf("Digite a Terceira nota: ");
    scanf("%f", &c);
    
    media = (a + b + c)/3;
    printf("A média é: %f", media);
}
