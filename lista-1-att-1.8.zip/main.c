#include <stdio.h>

int main()
{
    int A, B;
    printf("Digite o valor A: ");
    scanf("%d", &A);
    
    printf("Digite o valor B: ");
    scanf("%d", &B);
    
    A = A + B ;
    B = A - B ;
    A = A - B ;
    
    printf("A = %d, B= %d.", A, B);
}