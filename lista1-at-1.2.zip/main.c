/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float C, F;
    
    printf("Digite a temperatura em celsius: ");
    scanf("%f", &C);
    
    F = C * 9/5 + 32;
    
    printf("%f", F);
}

