#include <stdio.h>

int main()
{
    float kmL, kms, preçoComb, quantPessoas, preçoPPessoa;
    printf("Quantos quilômetros seu carro percorre por litro de combustível? ");
    scanf("%f", &kmL);
    
    printf("Quantos quilômetros pretende viajar de carro? ");
    scanf("%f", &kms);
    
    printf("Qual o valor do combustível no posto que costuma abastecer? ");
    scanf("%f", &preçoComb);
    
    printf("Quantas pessoas vão viajar e dividir a conta? ");
    scanf("%f", &quantPessoas);
    
    preçoPPessoa = ((kms/kmL) * preçoComb) / quantPessoas;
    
    printf("Cada pessoa irá gastar R$%f",preçoPPessoa);

}