#include <stdio.h>

int main()
{
    int tempo,tempoII, segundos, minutos, horas;
    printf("Digite quantos segundos deseja converter: ");
    scanf("%d", &tempo);
    
    segundos = tempo % 60;
    tempoII = tempo/60;
    minutos = tempoII % 60;
    horas = tempoII / 60;
    
    printf("O tempo é de %d horas, %d minutos e %d segundos.", horas, minutos, segundos);
}