/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
   int a, b, soma;
   printf("Digite o primeiro número: ");
   scanf("%d", &a);
   
   printf("Digite o segundo número: ");
   scanf("%d", &b);
   
   soma = a + b;
   printf("A soma dos números %d e %d é: %d", a, b, soma);
}